package com.example.NYCCab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NycCabApplicationTests {

	@Test
	void contextLoads() {
	}

}
